const { app, BrowserWindow, dialog, shell } = require("electron");
const http = require("http"), fs = require("fs"), path = require("path");
const xinput = require("./xinput");

const PORT = 3000, HOST = "127.0.0.1"; // local only
const clients = new Set();
let last = { c: 0 };

const dir = () => path.join(app.getPath("userData"), "overlays");
const names = () => fs.readdirSync(dir()).filter(f => /^[\w-]+\.html$/.test(f)).map(f => f.slice(0, -5));

function seed() { // copy bundled overlays on first run; users add their own in this folder
  fs.mkdirSync(dir(), { recursive: true });
  const src = path.join(__dirname, "overlays");
  for (const f of fs.readdirSync(src)) {
    const d = path.join(dir(), f);
    if (!fs.existsSync(d)) fs.copyFileSync(path.join(src, f), d);
  }
}

function broadcast(st) {
  last = st;
  const msg = "data: " + JSON.stringify(st) + "\n\n";
  for (const r of clients) r.write(msg);
}

const panel = () => `<!doctype html><html lang="en"><head><meta charset="utf-8">
<title>Gamepad Overlay</title><style>
body{margin:0;padding:20px;background:#0b0f0a;color:#eef4ea;font:15px/1.5 system-ui,sans-serif}
h1{font-size:1.3rem;margin:0 0 4px}p{color:#93a08d;margin:0 0 14px}
.card{background:#131a11;border:1px solid #243020;border-radius:14px;padding:12px;margin-bottom:10px}
code{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:6px 0 8px;color:#49e005}
button{font:inherit;cursor:pointer;border-radius:10px;border:1px solid #243020;background:#0b0f0a;color:#eef4ea;padding:7px 12px}
#st{margin-bottom:14px}</style></head><body>
<h1>Gamepad Overlay</h1><p>Copy a link into OBS or TikTok LIVE Studio.</p>
<div id="st" class="card">Waiting for controller…</div>
${names().map(n => `<div class="card"><b>${n}</b><code>http://localhost:${PORT}/o/${n}</code>
<button data-u="http://localhost:${PORT}/o/${n}">Copy link</button></div>`).join("")}
<button id="of">Open overlays folder</button>
<script>
document.addEventListener("click",function(e){var u=e.target.dataset.u;if(!u)return;
navigator.clipboard.writeText(u).then(function(){e.target.textContent="Copied ✓";
setTimeout(function(){e.target.textContent="Copy link"},1400)})});
document.getElementById("of").onclick=function(){fetch("/open-folder",{method:"POST",headers:{"x-app":"1"}})};
new EventSource("/events").onmessage=function(e){var s=JSON.parse(e.data);
document.getElementById("st").textContent=s.c?"Controller detected: "+s.id:"Waiting for controller…"};
</script></body></html>`;

const server = http.createServer((req, res) => {
  const p = new URL(req.url, "http://x").pathname;
  if (p === "/events") {
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-store", Connection: "keep-alive" });
    res.write("data: " + JSON.stringify(last) + "\n\n");
    clients.add(res);
    req.on("close", () => clients.delete(res));
    return;
  }
  if (p === "/shim.js") {
    return fs.readFile(path.join(__dirname, "shim.js"), (e, d) => {
      res.writeHead(e ? 500 : 200, { "Content-Type": "text/javascript", "Cache-Control": "no-store" });
      res.end(d);
    });
  }
  const m = p.match(/^\/o\/([\w-]+)$/);
  if (m) {
    return fs.readFile(path.join(dir(), m[1] + ".html"), "utf8", (e, h) => {
      if (e) { res.writeHead(404); return res.end("Overlay not found"); }
      const tag = '<script src="/shim.js"></script>';
      h = /<head[^>]*>/i.test(h) ? h.replace(/<head[^>]*>/i, x => x + tag) : tag + h;
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
      res.end(h);
    });
  }
  if (p === "/open-folder" && req.method === "POST" && req.headers["x-app"]) {
    shell.openPath(dir()); res.writeHead(204); return res.end();
  }
  if (p === "/") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return res.end(panel());
  }
  res.writeHead(404); res.end();
});

server.on("error", e => {
  dialog.showErrorBox("Gamepad Overlay", e.code === "EADDRINUSE"
    ? "Port " + PORT + " is already in use. Close the other copy of the app and try again."
    : String(e));
  app.quit();
});

app.whenReady().then(() => {
  seed();
  server.listen(PORT, HOST);
  try { xinput.start(broadcast); }
  catch (e) { dialog.showErrorBox("Gamepad Overlay", "Could not start controller reading: " + e.message); }
  const win = new BrowserWindow({ width: 460, height: 640, autoHideMenuBar: true, title: "Gamepad Overlay" });
  win.loadURL("http://localhost:" + PORT + "/");
});
app.on("window-all-closed", () => app.quit());
