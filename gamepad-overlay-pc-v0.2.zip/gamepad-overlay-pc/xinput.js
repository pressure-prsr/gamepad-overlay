// Reads the controller natively (works while the game has focus). Windows only.
const koffi = require("koffi");
const { toState } = require("./map");

function load() {
  for (const dll of ["xinput1_4.dll", "xinput9_1_0.dll"]) {
    try { return koffi.load(dll); } catch (e) {}
  }
  throw new Error("XInput DLL not found");
}

function start(onChange) {
  const lib = load();
  const PAD = koffi.struct("XINPUT_GAMEPAD", {
    wButtons: "uint16", bLeftTrigger: "uint8", bRightTrigger: "uint8",
    sThumbLX: "int16", sThumbLY: "int16", sThumbRX: "int16", sThumbRY: "int16"
  });
  koffi.struct("XINPUT_STATE", { dwPacketNumber: "uint32", Gamepad: PAD });
  const getState = lib.func("uint32 XInputGetState(uint32 dwUserIndex, _Out_ XINPUT_STATE *pState)");

  let lastKey = "";
  setInterval(() => {
    let st = null;
    for (let i = 0; i < 4; i++) {
      const raw = {};
      if (getState(i, raw) === 0) { st = toState(raw); break; }
    }
    const key = JSON.stringify(st);
    if (key !== lastKey) { lastKey = key; onChange(st || { c: 0 }); }
  }, 8);
}
module.exports = { start };
