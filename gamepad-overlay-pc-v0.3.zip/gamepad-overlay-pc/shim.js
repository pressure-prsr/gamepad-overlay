// Injected into every overlay: feeds navigator.getGamepads() from the PC app.
(function () {
  var pad = null;
  navigator.getGamepads = function () { return [pad, null, null, null]; };
  function connect() {
    var es = new EventSource("/events");
    es.onmessage = function (e) {
      var s = JSON.parse(e.data);
      pad = !s.c ? null : {
        id: s.id, index: 0, connected: true, mapping: "standard",
        timestamp: performance.now(), axes: s.a,
        buttons: s.b.map(function (v) { return { pressed: v > 0.5, touched: v > 0.5, value: v }; })
      };
    };
    es.onerror = function () { pad = null; };
  }
  connect();
})();
