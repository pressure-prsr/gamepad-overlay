// XInput -> W3C "standard" gamepad layout (what the overlays already read)
const BTN = [
  [0x1000, 0], [0x2000, 1], [0x4000, 2], [0x8000, 3],   // A B X Y
  [0x0100, 4], [0x0200, 5],                              // LB RB
  [0x0020, 8], [0x0010, 9],                              // Back Start
  [0x0040, 10], [0x0080, 11],                            // L3 R3
  [0x0001, 12], [0x0002, 13], [0x0004, 14], [0x0008, 15] // D-pad
];
const ax = v => Math.max(-1, Math.min(1, v / 32768));

function toState(s) {
  const g = s.Gamepad, b = new Array(17).fill(0);
  for (const [mask, i] of BTN) if (g.wButtons & mask) b[i] = 1;
  b[6] = g.bLeftTrigger / 255;
  b[7] = g.bRightTrigger / 255;
  return {
    c: 1,
    id: "Xbox Controller (XInput)",
    b,
    a: [ax(g.sThumbLX), -ax(g.sThumbLY) || 0, ax(g.sThumbRX), -ax(g.sThumbRY) || 0]
  };
}
module.exports = { toState };
